﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace OmarALZabir.AspectF
{
    internal class Logger 
    {
        public static readonly TextWriter Writer = Console.Out;
    }
}
